# Built-in skills

Shipped with Kor and installed into Kor's data folder on first use. Each skill keeps its
upstream licence in `LICENSE.upstream`.

| Source | Commit | Licence | Skills |
| --- | --- | --- | --- |
| https://github.com/addyosmani/agent-skills | 301b02b | MIT | api-and-interface-design, browser-testing-with-devtools, ci-cd-and-automation, code-review-and-quality, code-simplification, constraint-driven-development, context-engineering, debugging-and-error-recovery, deprecation-and-migration, documentation-and-adrs, doubt-driven-development, frontend-ui-engineering, git-workflow-and-versioning, idea-refine, incremental-implementation, interview-me, observability-and-instrumentation, performance-optimization, planning-and-task-breakdown, security-and-hardening, shipping-and-launch, source-driven-development, spec-driven-development, test-driven-development, using-agent-skills |
| https://github.com/sindresorhus/awesome | bc98e51 | CC0-1.0 | awesome-lists |
| https://github.com/blader/humanizer | b48c832 | MIT | humanizer |
| https://github.com/nateherkai/scroll-craft | 75d81f7 | MIT | scroll-craft |
| https://github.com/heygen-com/hyperframes | c218b37 | Apache-2.0 | figma, hyperframes, hyperframes-cli, hyperframes-registry, media-use, remotion-to-hyperframes, reverse-any-video, slideshow, style-sampling |

Changes made by Kor: agent-skills' shared `references/` folder is copied into each skill
that cites `../../references/` (and the path shortened to `references/`); HyperFrames
links `../hyperframes/…` are written `hyperframes:…` with a note to load them through the
`skill` tool; HyperFrames' "Usage beacon" lines and its automatic post-render feedback
instruction are removed from its SKILL.md files, with a note not to send either unless
the user asks; `awesome-lists/SKILL.md` is written by Kor around the awesome index. All
other files are unchanged.
