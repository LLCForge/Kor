---
name: awesome-lists
description: |
  Find curated "awesome" lists (sindresorhus/awesome) for a topic: libraries, tools, learning
  resources, frameworks. Use when the user asks for the best tools, libraries or resources for
  something, wants alternatives, or needs a starting point in an unfamiliar area.
license: CC0-1.0
---

# Awesome lists

`awesome.md` in this skill is the index of curated lists from
https://github.com/sindresorhus/awesome (CC0-1.0), grouped by area (Platforms, Programming
Languages, Front-End Development, Back-End Development, Computer Science, Big Data, Theory,
Books, Editors, Gaming, Development Environment, Entertainment, Databases, Media, Learn,
Security, Content Management Systems, Hardware, Business, Work, Networking, Decentralized
Systems, Health and Social Science, Events, Testing, Miscellaneous, Related).

1. Read `awesome.md` with the `skill` tool (`file: awesome.md`) and find the entries for the
   user's topic; search it for the topic's words first, it is long.
2. Give the matching lists with their links. When the user wants concrete picks, open the
   chosen list (WebFetch on its GitHub URL) and recommend from it, saying which list it came
   from.
3. The index is a snapshot; say so when recency matters, and check the live list.
